function clik(el){
    document.getElementById("bigPic").src=el.src;
    };